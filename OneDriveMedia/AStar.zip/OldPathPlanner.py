# Import any libraries required
import random

def is_valid(cell,grid):
    # Get the size of the grid
    COL = len(grid)
    ROW = len(grid[0])

    if (cell[0] < 0 or cell[0] >= ROW or cell[1] < 0 or cell[1] >= COL):
        return False
    else:
        return True

def is_blocked_cell(cell,grid):
    return grid[cell[0]][cell[1]]

def calculate_heuristic(cell,end):
    return (end[0]-cell[0]) + (end[1]-cell[1])

class Cell_class:
    def __init__(self,coords):
        self.parent = None
        self.g = 0
        self.h = 0
        self.f = 10000
        self.closed = False
        self.coords = coords 
        self.is_open = 1
    def get_f(self):
        return self.f
# The main path planning function. Additional functions, classes, 
# variables, libraries, etc. can be added to the file, but this
# function must always be defined with these arguments and must 
# return an array ('list') of coordinates (col,row).
#DO NOT EDIT THIS FUNCTION DECLARATION
def do_a_star(grid, start, end, display_message):
    #EDIT ANYTHING BELOW HERE
    
    
    # Get the size of the grid
    COL = len(grid)
    ROW = len(grid[0])

    closed_list = [ 
        [False for x in range(ROW)]
        for y in range(COL)
    ]
    closed_list[start[0]][start[1]] = True

    

    open_list = {start:0}

    display_message("Test")

    cell_grid = [
        [Cell_class(tuple((x,y))) for x in range(ROW)]
        for y in range(COL)
    ]

    display_message("Test")
    

    for x in range(ROW):
        for y in range(COL):
            display_message(f'{x},{y},')
            cell_grid[x-1][y-1].is_open = is_blocked_cell(tuple((x,y)),grid) 

    display_message("Valid Cell!")
    start_cell = Cell_class(tuple(start))
    
    directions = [[0,1],[1,0],[0,-1],[-1,0]]

    parent_grid = [ 
        [False for x in range(ROW)]
        for y in range(COL)
    ]

    display_message("Valid Cell!")

    parent_grid[start[0]][start[1]] = 0

    path = []
    display_message("Valid Cell!")
    path.append(start)
    i = 0
    
    while i < 100 :
        
        cell = min(open_list, key=open_list.get)
        class_cell = cell_grid[cell[0]][cell[1]]
        display_message(cell)
        display_message(class_cell.coords)
        display_message("Valid Cell!")
        for direction_item in directions:
            x = cell[0] + direction_item[0]
            y = cell[1] + direction_item[1]
            display_message(f'({x}, {y})')
            if is_valid([x,y],grid):
                if is_blocked_cell([x,y],grid):
                    display_message("Valid Cell!")
                    if closed_list[x][y] == False:
                        inspecting_cell = cell_grid[x][y]
                        if (x,y) == end:
                            display_message("End Reached!")
                            while inspecting_cell.parent != None:
                                path.append([x,y])
                                inspecting_cell = inspecting_cell.parent
                        else:
                            display_message("Calculating Heuristic")
                            g = class_cell.g + 1
                            h = calculate_heuristic([x,y],end)
                            f = g + h
                            if f < inspecting_cell.f:
                                inspecting_cell.f = f
                                inspecting_cell.parent = class_cell
                                inspecting_cell.g = g
                            #open_list.update({(x,y):f})
        open_list.pop(cell)
        closed_list[cell[0]][cell[1]] = True
        i += 1
    #path.append(cell)
    
    #max(d, key=d.get) 
    #path.append()



    # Print an example debug message
    display_message("Created random path points")
    display_message("Start location is " + str(start))

    # Send the path points back to the gui to be displayed
    #FUNCTION MUST ALWAYS RETURN A LIST OF (col,row) COORDINATES
    return path

#end of file