# Import any libraries required

def calculate_heuristic(cell,end):
    # Eclidian Distance, (x^2 + y^2)^0.5
    return pow(pow(end[0]-cell[0],2)+ pow(end[1]-cell[1],2),0.5)

def reconstruct_path(parent, current):
    # Takes a current node and a parent dictionary, and then recursively loops but instead using the successor as the current node until it runs out of parents (i.e. you have reached the start since it is the only node without a node it came from)
    total_path = [current]
    while current in parent.keys():
        current = parent[current]
        total_path.insert(0,current) # inserting it at the front since we need it to start with the start node not the end.
    print(total_path)
    return total_path

def is_blocked_cell(cell,grid):
    return grid[cell[0]][cell[1]]

# The main path planning function. Additional functions, classes, 
# variables, libraries, etc. can be added to the file, but this
# function must always be defined with these arguments and must 
# return an array ('list') of coordinates (col,row).
#DO NOT EDIT THIS FUNCTION DECLARATION
def do_a_star(grid, start, end,display_message):
    
    # Instead of marking cells as open or closed, they are added to a set of open nodes, and removed when closed.
    # Openset stores a dictionary of coordinates (nodes) with their associated f value for comparison.
    open_set = {(start[0],start[1]):0}

    # Get the size of the grid
    COL = len(grid)
    ROW = len(grid[0])

    #"We can keep track of the minimum cost path from s to each node encountered as follows. Each time a node is expanded, we store with each successor node n both the cost of getting to n by the lowest cost path found thus far,"
    # This requires us to store three things, the movement cost and the heuristic cost for each node, and the relationships between nodes, which can then be accessed to update future nodes with their own total costs until reaching the goal.
    
    # This dictionary is used to store previous node from each explored node. Which can then be used to reconstruct the path to the goal.
    cameFrom = {}
    
    
    g_score = {
        tuple([x,y]):999999 #### Instaniated at 999,999. If are working with a bigger grid of significantly increased costs, set this to infinity.
        for x in range(COL)
        for y in range(ROW)
    }

    g_score[(start[0],start[1])] = 0

    f_score = {
        tuple([x,y]):999999 
        for x in range(COL)
        for y in range(ROW)
    }

    f_score[(start[0],start[1])] = calculate_heuristic(start,end)

    directions = [[0,1],[1,0],[0,-1],[-1,0]] # Cardinal Directions.

    while len(open_set) > 0:
        # "Resolve ties arbitrarily, but always in favor of any node n E T.
        # Due to how the min function works, in the case of a tie, it will pick the first element, this is troublesome since we need it to select T nodes in the event of a tie.
        current = min(open_set, key=open_set.get) # Find the node in the open set with the lowest f value.

        if end in open_set: #If we have the end in the open_set.
            if open_set[end] == open_set[current]: # If the end has tied with the current mimumum (including itself)
                current = end # Actually we will pick in favour of the goal node T.
                return reconstruct_path(cameFrom,current)
        
        open_set.pop((current[0],current[1])) # Pre-emptively closing the node.

        for dir in directions: # Our Gamma operator/ expansion function. Iterate through all neighouring nodes (that are valid). Node ((x,y)) is the nieghbour we are inspecting while (current) is the parent.
            x = current[0] + dir[0]
            y = current[1] + dir[1]
            if x >= 0 and x < COL and y >= 0 and y < ROW: # If it is out of bounds, do not allow it.
                if is_blocked_cell((x,y),grid): # If it has an obstacale, do not allow it.

                    temp_f_score = g_score[current] + 1 + calculate_heuristic((x,y),end) # Calculating the full fscore.

                    if temp_f_score < g_score[(x,y)]: # If this node has a better fscore than it previously has been assigned:
                        cameFrom[(x,y)] = current # Update the predecessor
                        g_score[(x,y)] = g_score[current] + 1 
                        f_score[(x,y)] = temp_f_score # Update the f score

                        # "Remark as open any closed node n, which is a successor of n and for which f(n) is smaller now than it was when n, was marked closed."
                        open_set.update({(x,y):f_score[(x,y)]}) # Add/update the open set.
    
    display_message("No Path to Goal Available") # In this case we have iterated through all open nodes and NOT found the goal node. Failure.
    return [start]

#end of file