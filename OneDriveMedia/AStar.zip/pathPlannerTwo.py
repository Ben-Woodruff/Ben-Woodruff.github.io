# Import any libraries required
import random

def calculate_heuristic(cell,end):
    return (end[0]-cell[0]) + (end[1]-cell[1])

def reconstruct_path(Parent, current):
    total_path = [current]
    while current in Parent.keys():
        current = Parent[current]
        total_path.insert(0,current)
    print(total_path)
    return total_path


# The main path planning function. Additional functions, classes, 
# variables, libraries, etc. can be added to the file, but this
# function must always be defined with these arguments and must 
# return an array ('list') of coordinates (col,row).
#DO NOT EDIT THIS FUNCTION DECLARATION
def do_a_star(grid, start, end):
    #EDIT ANYTHING BELOW HERE
    
    #display_message("Started")

    openSet = {(start[0],start[1]):0}

    # Get the size of the grid
    COL = len(grid)
    ROW = len(grid[0])

    cameFrom = {}

    gScore = {
        tuple([x,y]):999999 
        for x in range(ROW)
        for y in range(COL)
    }
    gScore[(start[0],start[1])] = 0

    fScore = {
        tuple([x,y]):999999 
        for x in range(ROW)
        for y in range(COL)
    }

    fScore[(start[0],start[1])] = calculate_heuristic(start,end)

    directions = [[0,1],[1,0],[0,-1],[-1,0]]

    #display_message("Initialised!")

    while len(openSet) > 0:
        current = min(openSet, key=openSet.get)
        if current == end:
            return reconstruct_path(cameFrom,current)
        openSet.pop((current[0],current[1]))

        for dir in directions:
            x = current[0] + dir[0]
            y = current[1] + dir[1]
            if x > 0 and x < ROW and y > 0 and y < COL:    
                temp_gScore = gScore[current] + 1
                if temp_gScore < gScore[(x,y)]:
                    cameFrom[(x,y)] = current
                    gScore[(x,y)] = temp_gScore
                    fScore[(x,y)] = temp_gScore + calculate_heuristic(current,end)
                    if not ((x,y) in openSet):
                        openSet.update({(x,y):fScore[(x,y)]})

    # Print an example debug message
    #display_message("Created random path points")
    #display_message("Start location is " + str(start))

    # Send the path points back to the gui to be displayed
    #FUNCTION MUST ALWAYS RETURN A LIST OF (col,row) COORDINATES
    return end

#end of file
if __name__ == '__main__':
    do_a_star(
        grid= [ 
        [1 for x in range(20)]
        for y in range(10)
    ],start=(2,4),end=(18,5)
)